package com.example.bombball;

import android.graphics.Canvas;
import android.util.Log;

import java.util.ArrayList;

public class ArrowsCollection {
ArrayList<Arrow> ar;
ArrayList<Arrow> ar2;
private float wScreen, hScreen;
    public ArrowsCollection(float width,float height)
    {
        this.wScreen=width;
        this.hScreen=height;
        ar = new ArrayList<>();
        ar2=new ArrayList<>();
    }
    public Arrow get(int index) {
        return ar.get(index);
    }
    public void remove(Arrow a) {
        ar.remove(a);
    }
    public void add(Man man)
    {
        Arrow arrow = new Arrow(wScreen, hScreen, null);
        ar.add(arrow);
        arrow.x=man.x+(man.w/2);
        arrow.x-=arrow.w/2;
        arrow.y=man.y-50;
    }
    public void move(boolean split)
    {
        if (!split)
        {
            for(Arrow a : ar)
            {
                a.move();
            }
        }
        else
        {
            for(Arrow a : ar)
            {
                a.move();
            }
            for(Arrow b: ar2)
            {
                b.move();
            }
        }

    }

    public void draw(Canvas canvas,boolean split)
    {
        if(!split)
        {
            for(Arrow a : ar)
            {
                a.draw(canvas);

            }
        }
        else
        {
            for(Arrow a : ar)
            {
                a.draw(canvas);
            }
            for(Arrow b: ar2)
            {
                b.draw(canvas);
            }
        }

    }
    public void splitArrow(Man man)
    {
        Arrow arrow = new Arrow(wScreen, hScreen, null);
        ar.add(arrow);
        Arrow arrow2 = new Arrow(wScreen, hScreen, null);
        ar2.add(arrow2);
        arrow.x=man.x-(man.w/2)-30;
        arrow2.x=man.x+(man.w/2)+30;
        arrow.y=man.y-50;
        arrow2.y=man.y-50;
    }
    public int size()
    {
        int num=0;
        for(Arrow a : ar)
        {
            num++;
        }
        return num;
    }
    public void remove() {
        for (int i = 0; i < ar.size(); i++) {
            if (ar.get(i).ifTop() == true) {
                ar.remove(ar.get(i));
            }
        }
    }

}
